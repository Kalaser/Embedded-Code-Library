cmake_minimum_required(VERSION 3.13)

if(NOT PICO_SDK_PATH AND DEFINED ENV{PICO_SDK_PATH})
    set(PICO_SDK_PATH "$ENV{PICO_SDK_PATH}")
endif()
if(NOT PICO_SDK_PATH)
    message(FATAL_ERROR "Set PICO_SDK_PATH to your Raspberry Pi Pico SDK checkout")
endif()

include(${PICO_SDK_PATH}/external/pico_sdk_import.cmake)
project(ecl_pico_project C CXX ASM)
set(CMAKE_C_STANDARD 11)
set(CMAKE_CXX_STANDARD 17)

pico_sdk_init()

add_executable(ecl_pico_project src/main.c)
target_link_libraries(ecl_pico_project pico_stdlib)
pico_enable_stdio_usb(ecl_pico_project 1)
pico_enable_stdio_uart(ecl_pico_project 0)
pico_add_extra_outputs(ecl_pico_project)

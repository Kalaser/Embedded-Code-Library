#include "pico/stdlib.h"

int main(void)
{
    stdio_init_all();
    while (true) {
        printf("Pico SDK application template\n");
        sleep_ms(1000);
    }
}

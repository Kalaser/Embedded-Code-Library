#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

static volatile sig_atomic_t g_stop;

static void on_signal(int signo)
{
    (void)signo;
    g_stop = 1;
}

int main(void)
{
    struct sigaction action;
    struct timespec delay = {0, 100000000L};

    memset(&action, 0, sizeof(action));
    action.sa_handler = on_signal;
    if (sigemptyset(&action.sa_mask) != 0 ||
        sigaction(SIGINT, &action, NULL) != 0 ||
        sigaction(SIGTERM, &action, NULL) != 0) {
        perror("signal setup");
        return 1;
    }

    puts("embedded Linux app started");
    while (g_stop == 0) {
        /* Bounded wait: shutdown is checked even if a signal arrives before sleep. */
        (void)nanosleep(&delay, NULL);
    }
    puts("embedded Linux app stopped");
    return 0;
}

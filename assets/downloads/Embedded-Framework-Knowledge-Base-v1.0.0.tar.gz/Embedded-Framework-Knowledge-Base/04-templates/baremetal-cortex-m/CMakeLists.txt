cmake_minimum_required(VERSION 3.20)
project(ecl_cortex_m_firmware C ASM)

set(ECL_CPU "cortex-m4" CACHE STRING "Cortex-M CPU core, e.g. cortex-m0plus/cortex-m4/cortex-m33")
set(ECL_FPU "" CACHE STRING "Optional FPU flags, e.g. -mfpu=fpv4-sp-d16")
set(ECL_FLOAT_ABI "" CACHE STRING "Optional float ABI, e.g. -mfloat-abi=hard")
set(ECL_LINKER_SCRIPT "" CACHE FILEPATH "Target linker script")
set(ECL_STARTUP_SOURCE "" CACHE FILEPATH "Target startup assembly source")

if(NOT ECL_LINKER_SCRIPT OR NOT EXISTS "${ECL_LINKER_SCRIPT}")
    message(FATAL_ERROR "Set ECL_LINKER_SCRIPT to the target MCU linker script")
endif()
if(NOT ECL_STARTUP_SOURCE OR NOT EXISTS "${ECL_STARTUP_SOURCE}")
    message(FATAL_ERROR "Set ECL_STARTUP_SOURCE to the target startup assembly")
endif()
if(NOT EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/src/board_port.c")
    message(FATAL_ERROR "Copy src/board_port_stub.c.example to src/board_port.c and implement it")
endif()

add_executable(firmware
    "${ECL_STARTUP_SOURCE}"
    src/main.c
    src/app.c
    src/board_port.c
)

target_include_directories(firmware PRIVATE include)
target_compile_features(firmware PRIVATE c_std_11)
target_compile_options(firmware PRIVATE
    -mcpu=${ECL_CPU} -mthumb
    ${ECL_FPU} ${ECL_FLOAT_ABI}
    -ffunction-sections -fdata-sections
    -Wall -Wextra -Wpedantic
)
target_link_options(firmware PRIVATE
    -mcpu=${ECL_CPU} -mthumb
    ${ECL_FPU} ${ECL_FLOAT_ABI}
    "-T${ECL_LINKER_SCRIPT}"
    -Wl,--gc-sections
    "-Wl,-Map=${CMAKE_CURRENT_BINARY_DIR}/firmware.map"
    --specs=nano.specs --specs=nosys.specs
)

#ifndef APP_H_
#define APP_H_
void app_init(void);
void app_process(void);
#endif

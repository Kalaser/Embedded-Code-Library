#ifndef BOARD_PORT_H_
#define BOARD_PORT_H_
#include <stdint.h>
void board_init(void);
uint32_t board_tick_ms(void);
void board_idle(void);
#endif

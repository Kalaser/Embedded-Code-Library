#include "app.h"
#include "board_port.h"

static uint32_t s_last_tick;

void app_init(void)
{
    s_last_tick = board_tick_ms();
}

void app_process(void)
{
    const uint32_t now = board_tick_ms();
    if ((uint32_t)(now - s_last_tick) >= 1000U) {
        s_last_tick = now;
        /* TODO: run a bounded periodic service. */
    }
}

#include "app.h"
#include "board_port.h"

int main(void)
{
    board_init();
    app_init();

    for (;;) {
        app_process();
        board_idle();
    }
}

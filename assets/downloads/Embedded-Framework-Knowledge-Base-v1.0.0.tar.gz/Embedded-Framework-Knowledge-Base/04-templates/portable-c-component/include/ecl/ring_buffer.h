#ifndef ECL_RING_BUFFER_H_
#define ECL_RING_BUFFER_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint8_t *storage;
    size_t capacity;
    size_t head;
    size_t tail;
    size_t count;
} ecl_ring_buffer_t;

/*
 * Initialize a byte ring buffer using caller-owned storage.
 * The storage must remain valid for the lifetime of the ring buffer.
 * This component is not internally synchronized. Initialize successfully
 * before calling any other API. Input/output buffers must not overlap storage.
 */
bool ecl_ring_buffer_init(ecl_ring_buffer_t *rb,
                          uint8_t *storage,
                          size_t capacity);

size_t ecl_ring_buffer_size(const ecl_ring_buffer_t *rb);
size_t ecl_ring_buffer_free(const ecl_ring_buffer_t *rb);
bool ecl_ring_buffer_is_empty(const ecl_ring_buffer_t *rb);
bool ecl_ring_buffer_is_full(const ecl_ring_buffer_t *rb);

/* Returns number of bytes actually written/read. */
size_t ecl_ring_buffer_write(ecl_ring_buffer_t *rb,
                             const uint8_t *data,
                             size_t length);
size_t ecl_ring_buffer_read(ecl_ring_buffer_t *rb,
                            uint8_t *data,
                            size_t length);

void ecl_ring_buffer_reset(ecl_ring_buffer_t *rb);

#endif /* ECL_RING_BUFFER_H_ */

#include "ecl/ring_buffer.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    uint8_t storage[5];
    uint8_t input1[] = {1U, 2U, 3U, 4U};
    uint8_t input2[] = {5U, 6U, 7U};
    uint8_t output[8] = {0U};
    ecl_ring_buffer_t rb;

    assert(ecl_ring_buffer_init(&rb, storage, sizeof(storage)));
    assert(ecl_ring_buffer_write(&rb, input1, sizeof(input1)) == 4U);
    assert(ecl_ring_buffer_read(&rb, output, 3U) == 3U);
    assert(output[0] == 1U && output[1] == 2U && output[2] == 3U);
    assert(ecl_ring_buffer_write(&rb, input2, sizeof(input2)) == 3U);
    assert(ecl_ring_buffer_size(&rb) == 4U);
    assert(ecl_ring_buffer_read(&rb, output, sizeof(output)) == 4U);
    assert(output[0] == 4U && output[1] == 5U && output[2] == 6U && output[3] == 7U);
    assert(ecl_ring_buffer_is_empty(&rb));
    assert(!ecl_ring_buffer_init(&rb, storage, 0U));

    puts("ring buffer tests passed");
    return 0;
}

cmake_minimum_required(VERSION 3.16)
project(ecl_ring_buffer C)

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_C_EXTENSIONS OFF)

add_library(ecl_ring_buffer STATIC src/ring_buffer.c)
target_include_directories(ecl_ring_buffer PUBLIC include)
target_compile_options(ecl_ring_buffer PRIVATE
    $<$<C_COMPILER_ID:GNU,Clang>:-Wall;-Wextra;-Wpedantic;-Wconversion;-Wshadow>
)

option(ECL_BUILD_TESTS "Build host tests" ON)
if(ECL_BUILD_TESTS)
    enable_testing()
    add_executable(test_ring_buffer tests/test_ring_buffer.c)
    target_link_libraries(test_ring_buffer PRIVATE ecl_ring_buffer)
    add_test(NAME ring_buffer COMMAND test_ring_buffer)
endif()

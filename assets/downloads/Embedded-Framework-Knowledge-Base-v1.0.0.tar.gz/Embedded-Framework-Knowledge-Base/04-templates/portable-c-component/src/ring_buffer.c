#include "ecl/ring_buffer.h"

#include <string.h>

bool ecl_ring_buffer_init(ecl_ring_buffer_t *rb,
                          uint8_t *storage,
                          size_t capacity)
{
    if (rb == NULL || storage == NULL || capacity == 0U) {
        return false;
    }

    rb->storage = storage;
    rb->capacity = capacity;
    rb->head = 0U;
    rb->tail = 0U;
    rb->count = 0U;
    return true;
}

size_t ecl_ring_buffer_size(const ecl_ring_buffer_t *rb)
{
    return (rb != NULL) ? rb->count : 0U;
}

size_t ecl_ring_buffer_free(const ecl_ring_buffer_t *rb)
{
    if (rb == NULL || rb->capacity < rb->count) {
        return 0U;
    }
    return rb->capacity - rb->count;
}

bool ecl_ring_buffer_is_empty(const ecl_ring_buffer_t *rb)
{
    return (rb == NULL) || (rb->count == 0U);
}

bool ecl_ring_buffer_is_full(const ecl_ring_buffer_t *rb)
{
    return (rb != NULL) && (rb->count == rb->capacity);
}

size_t ecl_ring_buffer_write(ecl_ring_buffer_t *rb,
                             const uint8_t *data,
                             size_t length)
{
    size_t writable;
    size_t first;

    if (rb == NULL || data == NULL || rb->storage == NULL || rb->capacity == 0U) {
        return 0U;
    }

    writable = ecl_ring_buffer_free(rb);
    if (length < writable) {
        writable = length;
    }

    first = rb->capacity - rb->head;
    if (first > writable) {
        first = writable;
    }

    if (first > 0U) {
        (void)memcpy(&rb->storage[rb->head], data, first);
    }
    if (writable > first) {
        (void)memcpy(rb->storage, &data[first], writable - first);
    }

    if (writable >= (rb->capacity - rb->head)) {
        rb->head = writable - (rb->capacity - rb->head);
    } else {
        rb->head += writable;
    }
    rb->count += writable;
    return writable;
}

size_t ecl_ring_buffer_read(ecl_ring_buffer_t *rb,
                            uint8_t *data,
                            size_t length)
{
    size_t readable;
    size_t first;

    if (rb == NULL || data == NULL || rb->storage == NULL || rb->capacity == 0U) {
        return 0U;
    }

    readable = rb->count;
    if (length < readable) {
        readable = length;
    }

    first = rb->capacity - rb->tail;
    if (first > readable) {
        first = readable;
    }

    if (first > 0U) {
        (void)memcpy(data, &rb->storage[rb->tail], first);
    }
    if (readable > first) {
        (void)memcpy(&data[first], rb->storage, readable - first);
    }

    if (readable >= (rb->capacity - rb->tail)) {
        rb->tail = readable - (rb->capacity - rb->tail);
    } else {
        rb->tail += readable;
    }
    rb->count -= readable;
    return readable;
}

void ecl_ring_buffer_reset(ecl_ring_buffer_t *rb)
{
    if (rb != NULL) {
        rb->head = 0U;
        rb->tail = 0U;
        rb->count = 0U;
    }
}

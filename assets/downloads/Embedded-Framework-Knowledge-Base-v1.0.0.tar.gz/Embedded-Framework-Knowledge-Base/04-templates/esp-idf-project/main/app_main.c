#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

void app_main(void)
{
    puts("ESP-IDF application template");
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

#include <stdio.h>
int main(void) { puts("Buildroot external package template"); return 0; }

ECL_DEMO_VERSION = 1.0
ECL_DEMO_SITE = $(BR2_EXTERNAL_ECL_PATH)/package/ecl-demo/src
ECL_DEMO_SITE_METHOD = local
ECL_DEMO_LICENSE = MIT
ECL_DEMO_LICENSE_FILES = LICENSE

define ECL_DEMO_BUILD_CMDS
    $(TARGET_CC) $(TARGET_CFLAGS) $(TARGET_LDFLAGS) \
        -o $(@D)/ecl-demo $(@D)/main.c
endef

define ECL_DEMO_INSTALL_TARGET_CMDS
    $(INSTALL) -D -m 0755 $(@D)/ecl-demo $(TARGET_DIR)/usr/bin/ecl-demo
endef

$(eval $(generic-package))

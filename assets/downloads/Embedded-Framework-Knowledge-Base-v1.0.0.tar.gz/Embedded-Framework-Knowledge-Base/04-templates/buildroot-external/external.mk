include $(sort $(wildcard $(BR2_EXTERNAL_ECL_PATH)/package/*/*.mk))

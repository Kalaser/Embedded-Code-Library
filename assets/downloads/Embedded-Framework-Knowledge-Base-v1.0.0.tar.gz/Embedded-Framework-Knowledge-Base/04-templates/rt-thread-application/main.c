#include <rtthread.h>

int main(void)
{
    rt_kprintf("RT-Thread application template\n");

    while (1) {
        /* TODO: process application events or wait on a synchronization object. */
        rt_thread_mdelay(1000);
    }
}

#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>

int main(void)
{
    printk("Embedded framework knowledge base: Zephyr sample\n");
    while (1) {
        k_sleep(K_SECONDS(1));
        printk("application heartbeat\n");
    }
    return 0;
}

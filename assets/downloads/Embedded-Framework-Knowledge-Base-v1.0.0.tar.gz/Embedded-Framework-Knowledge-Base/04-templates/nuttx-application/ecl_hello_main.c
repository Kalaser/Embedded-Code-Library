#include <stdio.h>

int main(int argc, char *argv[])
{
    (void)argc;
    (void)argv;
    printf("NuttX application template\n");
    return 0;
}

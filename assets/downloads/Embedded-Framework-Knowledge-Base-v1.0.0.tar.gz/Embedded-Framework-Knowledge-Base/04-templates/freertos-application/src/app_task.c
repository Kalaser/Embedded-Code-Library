#include "FreeRTOS.h"
#include "task.h"
#include "app_task.h"

#define APP_TASK_STACK_WORDS  (configMINIMAL_STACK_SIZE + 128U)
#define APP_TASK_PRIORITY     (tskIDLE_PRIORITY + 1U)

static void app_worker(void *argument)
{
    TickType_t last_wake = xTaskGetTickCount();
    (void)argument;

    for (;;) {
        /* TODO: execute bounded application work. */
        vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(100U));
    }
}

BaseType_t app_tasks_init(void)
{
    return xTaskCreate(app_worker,
                       "app_worker",
                       APP_TASK_STACK_WORDS,
                       NULL,
                       APP_TASK_PRIORITY,
                       NULL);
}

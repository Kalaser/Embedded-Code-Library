#ifndef APP_TASK_H_
#define APP_TASK_H_
#include "FreeRTOS.h"
BaseType_t app_tasks_init(void);
#endif

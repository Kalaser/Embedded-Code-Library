#include "FreeRTOS.h"
#include "task.h"
#include "app_task.h"
#include "board.h"

int main(void)
{
    board_init();
    if (app_tasks_init() != pdPASS) {
        board_fatal_error();
    }
    vTaskStartScheduler();

    /* Reaching here usually means scheduler startup failed. */
    for (;;) {
        board_fatal_error();
    }
}

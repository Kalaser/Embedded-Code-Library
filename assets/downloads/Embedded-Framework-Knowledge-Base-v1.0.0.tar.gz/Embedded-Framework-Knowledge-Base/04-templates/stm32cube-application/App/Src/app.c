#include "app.h"

void app_init(void)
{
    /* Initialize product services after required HAL peripherals are ready. */
}

void app_process(void)
{
    /* Run bounded non-blocking application work. */
}

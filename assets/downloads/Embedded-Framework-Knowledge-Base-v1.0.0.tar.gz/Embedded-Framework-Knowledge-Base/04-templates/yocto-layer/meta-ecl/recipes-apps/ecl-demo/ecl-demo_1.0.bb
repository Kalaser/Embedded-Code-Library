SUMMARY = "Embedded framework knowledge base example application"
DESCRIPTION = "Minimal userspace application recipe template"
LICENSE = "MIT"
LIC_FILES_CHKSUM = "file://LICENSE;md5=f46adada8d8aa92614cd01dcae96a418"

SRC_URI = "file://main.c file://LICENSE"
S = "${WORKDIR}"

do_compile() {
    install -d ${B}
    ${CC} ${CFLAGS} ${LDFLAGS} ${S}/main.c -o ${B}/ecl-demo
}

do_install() {
    install -d ${D}${bindir}
    install -m 0755 ${B}/ecl-demo ${D}${bindir}/ecl-demo
}

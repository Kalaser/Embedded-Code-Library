#include <stdio.h>
int main(void) { puts("Yocto layer application template"); return 0; }
